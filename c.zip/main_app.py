import streamlit as st

# --- Import modular units ---
from unit_admin import admin_panel, apply_branding
from unit_processor import load_and_prepare_data, describe_summary, plot_preview
from unit_screens import init_screens, screen_router, render_screen

# 1. Apply branding/theme if set by admin
apply_branding()

# 2. Sidebar: High-level navigation
st.sidebar.title("🔗 Main Navigation")
main_section = st.sidebar.radio("Go to section", ["Admin Panel", "Data Processor", "Dashboard Screens"])

# 3. ADMIN PANEL TAB
if main_section == "Admin Panel":
    admin_panel()

# 4. DATA PROCESSOR TAB
elif main_section == "Data Processor":
    st.title("📦 Data Processing / Preparation")
    df, selections = load_and_prepare_data()
    if not df.empty:
        describe_summary(df)
        # Optionally show a preview plot if columns are selected
        if selections.get("date_col") and selections.get("value_col"):
            plot_preview(df, selections["date_col"], selections["value_col"])

# 5. DASHBOARD SCREENS TAB
elif main_section == "Dashboard Screens":
    # Define the list of screens for navigation
    screen_list = ["Home", "Overview", "Funnel", "Sector Summary", "Board Room", "Rest Area", "Admin Console"]
    init_screens(screen_list)
    screen_router(screen_list)
    render_screen(st.session_state["active_screen"])