import streamlit as st
import pandas as pd

def upload_section():
    st.subheader("📤 Upload Files")
    uploaded_files = st.file_uploader("Upload CSV/Excel files", type=["csv", "xlsx"], accept_multiple_files=True)
    file_dict = {}
    for file in uploaded_files or []:
        try:
            if file.name.endswith(".csv"):
                df = pd.read_csv(file)
            else:
                df = pd.read_excel(file)
            st.success(f"✅ {file.name} uploaded.")
            file_dict[file.name] = df
        except Exception as e:
            st.error(f"❌ Error loading {file.name}: {e}")
    return file_dict

def template_section():
    st.subheader("🎨 Template & Visual Assets")
    uploaded_images = st.file_uploader("Upload Visual Templates (PNG/JPG)", type=["png", "jpg"], accept_multiple_files=True)
    images = []
    for img in uploaded_images or []:
        images.append(img)
        st.image(img, width=150)
    return images

def security_section():
    st.subheader("🔐 Admin Security")
    enable_password = st.checkbox("Enable Dashboard Password")
    if enable_password:
        password = st.text_input("Set Password", type="password")
        st.session_state["admin_password"] = password
    if "admin_logged_in" not in st.session_state:
        st.session_state["admin_logged_in"] = False

    if enable_password:
        input_pass = st.text_input("Enter Password to Access", type="password")
        if input_pass == st.session_state.get("admin_password"):
            st.session_state["admin_logged_in"] = True
            st.success("✅ Access Granted")
        else:
            st.warning("🔒 Incorrect Password")
    else:
        st.session_state["admin_logged_in"] = True

def dashboard_settings():
    st.subheader("⚙️ Dashboard Settings")
    project_name = st.text_input("Project Name", value=st.session_state.get("project_name", "My Dashboard"))
    theme = st.selectbox("Select Theme", ["Default", "Royal Blue", "Dark Mode", "Pastel"])
    logo_url = st.text_input("Logo URL", value=st.session_state.get("logo_url", ""))

    st.session_state["project_name"] = project_name
    st.session_state["theme"] = theme
    st.session_state["logo_url"] = logo_url

    if logo_url:
        st.image(logo_url, width=150)

def admin_panel():
    st.title("🛠️ Admin Control Panel")

    security_section()
    if not st.session_state.get("admin_logged_in"):
        return

    tabs = st.tabs(["📂 Files", "🎨 Templates", "⚙️ Settings", "📦 Session", "🧭 Navigation"])
    with tabs[0]:
        files = upload_section()
        st.session_state["admin_uploaded_files"] = files

    with tabs[1]:
        templates = template_section()
        st.session_state["visual_templates"] = templates

    with tabs[2]:
        dashboard_settings()

    with tabs[3]:
        st.subheader("📦 Current Session State")
        st.json({k: str(v) for k, v in st.session_state.items()})

    with tabs[4]:
        st.subheader("🧭 Screen Flow Settings")
        flow = st.text_area("Define screen flow as dictionary (e.g., {'Home': ['Overview']})", height=150)
        try:
            flow_dict = eval(flow)
            st.session_state["screen_flow"] = flow_dict
            st.success("✅ Flow updated.")
        except Exception as e:
            st.error(f"❌ Invalid dictionary: {e}")

def apply_branding():
    theme = st.session_state.get("theme", "Default")
    css = ""
    if theme == "Royal Blue":
        css = """
        <style>
        body { background-color: #F9FAFC; color: #1F2E4D; }
        .stButton>button { background-color: #0070C0; color: white; }
        </style>
        """
    elif theme == "Dark Mode":
        css = """
        <style>
        body { background-color: #1E1E1E; color: white; }
        </style>
        """
    elif theme == "Pastel":
        css = """
        <style>
        body { background-color: #FAF4EF; color: #444; }
        </style>
        """
    if css:
        st.markdown(css, unsafe_allow_html=True)