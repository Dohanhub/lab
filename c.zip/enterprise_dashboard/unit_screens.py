import streamlit as st
from typing import Dict, List

def init_screens(screen_list: List[str], default: str = None):
    if "active_screen" not in st.session_state:
        st.session_state["active_screen"] = default or screen_list[0]
    if "screen_config" not in st.session_state:
        st.session_state["screen_config"] = {}
    if "nav_history" not in st.session_state:
        st.session_state["nav_history"] = []

def screen_router(screen_list: List[str]):
    st.sidebar.markdown("## 🧭 Navigate")
    choice = st.sidebar.radio("Go to", screen_list, index=screen_list.index(st.session_state["active_screen"]))
    st.session_state["active_screen"] = choice
    st.session_state["nav_history"].append(choice)

def render_layout(layout_type: str, content: Dict):
    st.markdown(f"### 📐 Layout: {layout_type}")
    if layout_type == "text_only":
        st.markdown(content.get("text", ""))
    elif layout_type == "single_image":
        st.image(content.get("image"), use_column_width=True)
    elif layout_type == "two_images":
        cols = st.columns(2)
        with cols[0]:
            st.image(content.get("left_image"), use_column_width=True)
        with cols[1]:
            st.image(content.get("right_image"), use_column_width=True)
    elif layout_type == "four_images":
        cols = st.columns(2)
        with cols[0]:
            st.image(content.get("img1"), use_column_width=True)
            st.image(content.get("img2"), use_column_width=True)
        with cols[1]:
            st.image(content.get("img3"), use_column_width=True)
            st.image(content.get("img4"), use_column_width=True)
    elif layout_type == "mixed":
        cols = st.columns([1, 2])
        with cols[0]:
            st.image(content.get("image"), use_column_width=True)
        with cols[1]:
            st.markdown(content.get("text", ""))
    else:
        st.warning("Layout type not recognized.")

def render_screen(name: str):
    screens = {
        "Home": home_screen,
        "Overview": overview_screen,
        "Funnel": funnel_screen,
        "Rest Area": rest_screen,
        "Sector Summary": sector_screen,
        "Board Room": board_screen,
        "Admin Console": admin_screen,
    }
    if name in screens:
        screens[name]()
    else:
        st.warning(f"Screen '{name}' is not defined.")

def home_screen():
    st.title("🏠 Welcome to the Analytics System")
    st.markdown("This is the central access point to your performance world.")
    render_layout("mixed", {
        "image": "https://images.unsplash.com/photo-1542744095-291d1f67b221",
        "text": "Access all your KPIs, dashboards, and team performance from the side menu."
    })

def overview_screen():
    st.title("📊 Sales Overview")
    st.markdown("This screen will contain high-level KPIs, cards, and trends.")
    st.success("✅ Integrated with `unit_processor` data.")
    st.metric("Revenue", "1,200,000 SAR")
    st.metric("Achievement", "92%")
    st.metric("Avg. Margin", "21.3%")

def funnel_screen():
    st.title("🔻 Funnel Analysis")
    st.markdown("Visualize opportunity stages, conversion, and win rates.")
    render_layout("two_images", {
        "left_image": "https://images.unsplash.com/photo-1573164574572-cb89e39749b4",
        "right_image": "https://images.unsplash.com/photo-1556740738-b6a63e27c4df"
    })

def rest_screen():
    st.title("☕ Coffee Break / Rest Area")
    st.markdown("Relax and recharge here. Inspirational or fun content may appear.")
    render_layout("single_image", {
        "image": "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd"
    })

def sector_screen():
    st.title("🏢 Sector Performance")
    st.markdown("Sector manager KPIs, achievements, and gaps.")
    render_layout("text_only", {
        "text": "🟩 Healthcare: 97% | 🟦 Education: 82% | 🟥 Oil & Gas: 69%"
    })

def board_screen():
    st.title("🧠 Board Room")
    st.markdown("Use this space to drive decisions with visual evidence.")
    render_layout("four_images", {
        "img1": "https://images.unsplash.com/photo-1573166364524-7fbb1f0b5819",
        "img2": "https://images.unsplash.com/photo-1549924231-f129b911e442",
        "img3": "https://images.unsplash.com/photo-1590650046871-92c8872df6bc",
        "img4": "https://images.unsplash.com/photo-1593642634367-d91a135587b5"
    })

def admin_screen():
    st.title("🛠️ Admin Console")
    st.markdown("Manage data, templates, and screen behaviors from here.")
    st.button("🔁 Reload Screen Configs")
    st.button("📂 Upload Visual Templates")
    st.text_area("Notes", placeholder="Internal notes for this cycle...")