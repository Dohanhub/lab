import streamlit as st
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.svm import SVC, SVR
import joblib
import io

try:
    from xgboost import XGBClassifier, XGBRegressor
    XGB_AVAILABLE = True
except ImportError:
    XGB_AVAILABLE = False
try:
    from lightgbm import LGBMClassifier, LGBMRegressor
    LGB_AVAILABLE = True
except ImportError:
    LGB_AVAILABLE = False

def ml_advanced_panel(df):
    st.subheader("Advanced ML Options and Export")
    target = st.selectbox("Target column", df.columns)
    task_type = st.radio("Task", ["Classification", "Regression"])

    model_choice = st.selectbox("Model", [
        "RandomForest", "XGBoost", "LightGBM", "LogisticRegression/SVR"
    ])
    if model_choice == "RandomForest":
        model = RandomForestClassifier() if task_type == "Classification" else RandomForestRegressor()
    elif model_choice == "XGBoost" and XGB_AVAILABLE:
        model = XGBClassifier(eval_metric="logloss") if task_type == "Classification" else XGBRegressor()
    elif model_choice == "LightGBM" and LGB_AVAILABLE:
        model = LGBMClassifier() if task_type == "Classification" else LGBMRegressor()
    elif model_choice == "LogisticRegression/SVR":
        model = LogisticRegression() if task_type == "Classification" else SVR()
    else:
        st.error("Selected model or library not installed.")
        return

    X = pd.get_dummies(df.drop(columns=[target]), drop_first=True)
    y = df[target]
    X = X.loc[y.notnull()]
    y = y[y.notnull()]
    test_size = st.slider("Test size", 0.1, 0.5, 0.2)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=42)

    if st.button("Train"):
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        st.success("Model trained!")
        st.write("Sample predictions:", y_pred[:10])

        buffer = io.BytesIO()
        joblib.dump(model, buffer)
        st.download_button(
            label="Download model (.pkl)",
            data=buffer.getvalue(),
            file_name="trained_model.pkl"
        )

        pred_df = pd.DataFrame({"y_true": y_test, "y_pred": y_pred})
        st.download_button(
            label="Download predictions (.csv)",
            data=pred_df.to_csv(index=False),
            file_name="predictions.csv"
        )