import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime
from sklearn.ensemble import IsolationForest
from statsmodels.tsa.holtwinters import ExponentialSmoothing
import plotly.express as px
import seaborn as sns
import matplotlib.pyplot as plt
import io

# ------------- CONFIGURATION -------------
st.set_page_config(layout="wide", page_title="Enterprise Analytics Dashboard")

# ------------- SIDEBAR NAVIGATION -------------
st.sidebar.title("🌐 Main Menu")
menu_options = [
    "Intro Screen", "Chat", "Image Upload/Record", "Calendar",
    "File/Data Upload", "Data Cleaning", "Preview Data", "Column Type Detection",
    "Missing Value Handling", "Custom Equation/Formula", "Analytics/Stats", "Anomaly Detection", 
    "Forecasting", "Correlation Matrix", "Charts/Visualization", "AI Copilot", "ML Modeling", 
    "Explainability/SHAP", "Model Export", "Prediction Export", "Collaboration", "Rest Area", 
    "End Screen", "Admin/Branding", "Dashboard Screens", "Session State", "Settings", "Audit Trail", "Security/Login", "User Roles"
]
choice = st.sidebar.selectbox("Select Feature", menu_options)

# ------------- SESSION STATE INIT -------------
if "chat_log" not in st.session_state:
    st.session_state["chat_log"] = []
if "df" not in st.session_state:
    st.session_state["df"] = pd.DataFrame()

# ------------- FEATURE DISPATCHER -------------

# --- 1. Intro Screen ---
if choice == "Intro Screen":
    st.title("🚀 Welcome to the Enterprise Analytics Dashboard!")
    st.image("https://images.unsplash.com/photo-1542744095-291d1f67b221", use_column_width=True)
    st.markdown("""
    - Unified analytics, ML, collaboration, and more
    - Use the sidebar to explore all features
    - [Documentation](#)
    """)
    st.info("Tip: Try uploading your own data or use the AI Copilot.")

# --- 2. Chat/Collaboration ---
elif choice == "Chat":
    st.header("💬 Chat & Collaboration")
    chat_input = st.text_input("Type a message and press Enter", key="chat_input")
    if chat_input:
        st.session_state["chat_log"].append((datetime.utcnow().strftime("%H:%M"), "You", chat_input))
        st.session_state["chat_input"] = ""
    st.markdown("#### Chat History")
    for time, user, msg in reversed(st.session_state["chat_log"]):
        st.markdown(f"**{user}** [{time}]: {msg}")
    st.caption("This is a simple session chat log. Expand for real-time or multi-user.")

# --- 3. Image Upload/Record ---
elif choice == "Image Upload/Record":
    st.header("🖼️ Upload or Record an Image")
    uploaded_img = st.file_uploader("Upload an image", type=["png", "jpg", "jpeg"])
    if uploaded_img:
        st.image(uploaded_img, caption="Uploaded Image", use_column_width=True)
    if hasattr(st, "camera_input"):
        img = st.camera_input("Take a picture")
        if img is not None:
            st.image(img, caption="Captured Image", use_column_width=True)
    else:
        st.info("Live camera not supported in this Streamlit version.")

# --- 4. Calendar ---
elif choice == "Calendar":
    st.header("📅 Calendar & Date Annotation")
    selected_date = st.date_input("Pick a date", value=datetime.utcnow().date())
    st.success(f"You selected: {selected_date}")
    note = st.text_area("Annotation/Note for this date:")
    if note:
        st.info(f"Note for {selected_date}: {note}")

# --- 5. File/Data Upload ---
elif choice == "File/Data Upload":
    st.header("📤 Upload CSV or Excel")
    uploaded = st.file_uploader("Choose a file", type=["csv", "xlsx"])
    if uploaded:
        if uploaded.name.endswith(".csv"):
            df = pd.read_csv(uploaded)
        else:
            df = pd.read_excel(uploaded)
        st.session_state["df"] = df
        st.success("File uploaded and loaded!")
        st.dataframe(df.head())
    else:
        st.info("Upload a file to start.")
    st.caption("File saved in session for downstream features.")

# --- 6. Data Cleaning ---
elif choice == "Data Cleaning":
    st.header("🧹 Data Cleaning")
    df = st.session_state.get("df", pd.DataFrame())
    if not df.empty:
        df.columns = [str(c).strip().replace(" ", "_").replace("/", "_").lower() for c in df.columns]
        for col in df.select_dtypes(include=["float", "int"]).columns:
            df[col] = df[col].fillna(df[col].mean())
        for col in df.select_dtypes(include=["object"]).columns:
            df[col] = df[col].fillna("N/A")
        st.session_state["df"] = df
        st.success("Cleaned column names and filled missing values.")
        st.dataframe(df.head())
    else:
        st.warning("Please upload data first.")

# --- 7. Preview Data ---
elif choice == "Preview Data":
    st.header("Preview Data")
    df = st.session_state.get("df", pd.DataFrame())
    if not df.empty:
        st.dataframe(df.head(20), use_container_width=True)
        st.markdown(f"**Shape:** {df.shape[0]} rows × {df.shape[1]} columns")
    else:
        st.warning("Please upload data first.")

# --- 8. Column Type Detection ---
elif choice == "Column Type Detection":
    st.header("Column Type Detection")
    df = st.session_state.get("df", pd.DataFrame())
    if not df.empty:
        st.write("Numeric:", df.select_dtypes(include=["int", "float"]).columns.tolist())
        st.write("Date:", df.select_dtypes(include=["datetime"]).columns.tolist())
        st.write("Text:", df.select_dtypes(include=["object"]).columns.tolist())
    else:
        st.warning("Please upload data first.")

# --- 9. Missing Value Handling ---
elif choice == "Missing Value Handling":
    st.header("Missing Value Handling")
    df = st.session_state.get("df", pd.DataFrame())
    if not df.empty:
        st.write(df.isnull().sum())
    else:
        st.warning("Please upload data first.")

# --- 10. Custom Equation/Formula ---
elif choice == "Custom Equation/Formula":
    st.header("Custom Formula/Equation")
    df = st.session_state.get("df", pd.DataFrame())
    if not df.empty:
        columns = df.columns.tolist()
        col1 = st.selectbox("Column 1", columns)
        op = st.selectbox("Operation", ["+", "-", "*", "/"])
        col2 = st.selectbox("Column 2", columns)
        new_col = st.text_input("New column name", value=f"{col1}{op}{col2}")
        if st.button("Add Calculated Column"):
            try:
                if op == "+":
                    df[new_col] = df[col1] + df[col2]
                elif op == "-":
                    df[new_col] = df[col1] - df[col2]
                elif op == "*":
                    df[new_col] = df[col1] * df[col2]
                elif op == "/":
                    df[new_col] = df[col1] / df[col2]
                st.session_state["df"] = df
                st.success(f"Added column: {new_col}")
                st.dataframe(df.head())
            except Exception as e:
                st.error(f"Formula error: {e}")
    else:
        st.warning("Please upload data first.")

# --- 11. Analytics/Stats ---
elif choice == "Analytics/Stats":
    st.header("📊 Statistical Summary")
    df = st.session_state.get("df", pd.DataFrame())
    if not df.empty:
        st.dataframe(df.describe(include="all"), use_container_width=True)
    else:
        st.warning("Please upload data first.")

# --- 12. Anomaly Detection ---
elif choice == "Anomaly Detection":
    st.header("Anomaly Detection")
    df = st.session_state.get("df", pd.DataFrame())
    if not df.empty:
        num_cols = df.select_dtypes("number").columns
        for col in num_cols:
            if len(df) > 10:
                model = IsolationForest(contamination=0.05, random_state=0)
                preds = model.fit_predict(df[[col]].fillna(0))
                anomalies = df.loc[preds == -1, col]
                if not anomalies.empty:
                    st.warning(f"Anomalies in {col}: {len(anomalies)} rows")
                    st.write(anomalies.head())
            else:
                st.info(f"Not enough data for anomaly detection in {col}.")
    else:
        st.warning("Please upload data first.")

# --- 13. Forecasting ---
elif choice == "Forecasting":
    st.header("📈 Forecasting")
    df = st.session_state.get("df", pd.DataFrame())
    if not df.empty:
        date_cols = df.select_dtypes("datetime").columns
        num_cols = df.select_dtypes("number").columns
        if len(date_cols) > 0 and len(num_cols) > 0:
            date_col = date_cols[0]
            target_col = num_cols[0]
            ts = df[[date_col, target_col]].dropna()
            ts = ts.set_index(date_col)
            if len(ts) > 12:
                model = ExponentialSmoothing(ts[target_col], trend="add", seasonal=None)
                fit = model.fit()
                forecast = fit.forecast(steps=12)
                st.line_chart(pd.concat([ts[target_col], forecast.rename("Forecast")]))
            else:
                st.info("Need at least 12 data points for forecasting.")
        else:
            st.info("Upload a file with a datetime and numeric column.")
    else:
        st.warning("Please upload data first.")

# --- 14. Correlation Matrix ---
elif choice == "Correlation Matrix":
    st.header("Correlation Matrix")
    df = st.session_state.get("df", pd.DataFrame())
    if not df.empty:
        num_cols = df.select_dtypes("number").columns
        if len(num_cols) > 1:
            corr = df[num_cols].corr()
            st.dataframe(corr)
            fig, ax = plt.subplots()
            sns.heatmap(corr, annot=True, cmap="coolwarm", ax=ax)
            st.pyplot(fig)
        else:
            st.info("Need at least two numeric columns.")
    else:
        st.warning("Please upload data first.")

# --- 15. Charts/Visualization ---
elif choice == "Charts/Visualization":
    st.header("Charts & Visualization")
    df = st.session_state.get("df", pd.DataFrame())
    if not df.empty:
        columns = df.columns.tolist()
        chart_type = st.selectbox("Chart Type", ["Bar", "Line", "Scatter", "Histogram", "Box", "Pie"])
        x = st.selectbox("X axis", columns)
        y = st.selectbox("Y axis", columns)
        fig = None
        if chart_type == "Bar":
            fig = px.bar(df, x=x, y=y)
        elif chart_type == "Line":
            fig = px.line(df, x=x, y=y)
        elif chart_type == "Scatter":
            fig = px.scatter(df, x=x, y=y)
        elif chart_type == "Box":
            fig = px.box(df, x=x, y=y)
        elif chart_type == "Histogram":
            fig = px.histogram(df, x=x)
        elif chart_type == "Pie":
            fig = px.pie(df, names=x)
        if fig:
            st.plotly_chart(fig, use_container_width=True)
    else:
        st.warning("Please upload data first.")

# --- 16. AI Copilot (Stub) ---
elif choice == "AI Copilot":
    st.header("🤖 AI Chart/KPI Copilot")
    st.info("Stub: Integrate OpenAI/LLM API for chart & KPI recommendations based on your data.")

# --- 17. ML Modeling (Stub) ---
elif choice == "ML Modeling":
    st.header("ML Modeling & Export")
    st.info("Stub: Train ML models (RandomForest, XGBoost, LightGBM, etc). Export model/predictions. Expand here.")

# --- 18. Explainability/SHAP (Stub) ---
elif choice == "Explainability/SHAP":
    st.header("Explainability (SHAP)")
    st.info("Stub: Integrate SHAP explainability for ML models here.")

# --- 19. Model Export (Stub) ---
elif choice == "Model Export":
    st.header("Model Export")
    st.info("Export trained ML models as .pkl files. See ML Modeling tab.")

# --- 20. Prediction Export (Stub) ---
elif choice == "Prediction Export":
    st.header("Prediction Export")
    st.info("Export model predictions as .csv. See ML Modeling tab.")

# --- 21. Collaboration (Stub) ---
elif choice == "Collaboration":
    st.header("User/Team Collaboration")
    st.info("Stub: Real-time sync, comments, and sharing will appear here.")

# --- 22. Rest Area ---
elif choice == "Rest Area":
    st.title("☕ Rest Area / Coffee Break")
    st.image("https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd", use_column_width=True)
    st.markdown("Take a break. Enjoy a quote or some music.")
    st.info("“The best way to get started is to quit talking and begin doing.” – Walt Disney")
    st.audio("https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3")

# --- 23. End Screen ---
elif choice == "End Screen":
    st.title("🏁 End of Dashboard")
    st.balloons()
    st.markdown("Thank you for using the Enterprise Dashboard!")
    st.text_area("Feedback", placeholder="Leave your feedback here...")
    st.info("Come back again soon!")

# --- 24. Admin/Branding (Stub) ---
elif choice == "Admin/Branding":
    st.header("Admin Panel & Branding")
    st.info("Stub: Set logo, theme, user roles, password. Expand as needed.")

# --- 25. Dashboard Screens (Stub) ---
elif choice == "Dashboard Screens":
    st.header("Dashboard Screens")
    screens = ["Home", "Overview", "Funnel", "Rest", "Board Room", "End"]
    page = st.selectbox("Go to screen", screens)
    st.success(f"Now viewing: {page}")
    st.info("Stub: Expand with rich layouts and navigation.")

# --- 26. Session State ---
elif choice == "Session State":
    st.header("Session State")
    st.json({k: str(v) for k, v in st.session_state.items()})

# --- 27. Settings (Stub) ---
elif choice == "Settings":
    st.header("Settings")
    st.info("Stub: Organization preferences, feature toggles, language, etc.")

# --- 28. Audit Trail (Stub) ---
elif choice == "Audit Trail":
    st.header("Audit Trail/Changelog")
    st.info("Stub: Show all dashboard actions, who did what/when.")

# --- 29. Security/Login (Stub) ---
elif choice == "Security/Login":
    st.header("Security/Login")
    st.info("Stub: Add login/password, multi-user SSO, 2FA, etc.")

# --- 30. User Roles (Stub) ---
elif choice == "User Roles":
    st.header("User Roles")
    st.info("Stub: Multi-user roles/permissions (Admin, Editor, Viewer, etc.)")

else:
    st.write("Select a feature from the sidebar to begin.")

# ----------------- END OF APP -----------------