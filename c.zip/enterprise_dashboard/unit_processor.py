import streamlit as st
import pandas as pd
import numpy as np
from typing import Tuple, Dict, List

def upload_data() -> pd.DataFrame:
    st.subheader("📤 Upload Your File")
    file = st.file_uploader("Choose an Excel or CSV file", type=["xlsx", "csv"])
    if file:
        if file.name.endswith(".csv"):
            df = pd.read_csv(file)
        else:
            sheet_name = st.text_input("📄 Enter Sheet Name (default = first sheet):", value=None)
            try:
                df = pd.read_excel(file, sheet_name=sheet_name if sheet_name else 0)
            except Exception as e:
                st.error(f"Error loading sheet: {e}")
                return pd.DataFrame()
        st.success(f"✅ File '{file.name}' uploaded successfully.")
        return df
    else:
        st.info("Awaiting file upload...")
        return pd.DataFrame()

def clean_column_names(df: pd.DataFrame) -> pd.DataFrame:
    df.columns = [str(col).strip().replace(" ", "_").replace("/", "_").lower() for col in df.columns]
    return df

def fill_missing(df: pd.DataFrame, strategy: str = "mean") -> pd.DataFrame:
    df_copy = df.copy()
    for col in df_copy.select_dtypes(include=["float", "int"]).columns:
        if strategy == "mean":
            df_copy[col] = df_copy[col].fillna(df_copy[col].mean())
        elif strategy == "median":
            df_copy[col] = df_copy[col].fillna(df_copy[col].median())
        elif strategy == "zero":
            df_copy[col] = df_copy[col].fillna(0)
    for col in df_copy.select_dtypes(include=["object"]).columns:
        df_copy[col] = df_copy[col].fillna("N/A")
    return df_copy

def get_column_types(df: pd.DataFrame) -> Dict[str, List[str]]:
    numeric = df.select_dtypes(include=["int", "float"]).columns.tolist()
    date = df.select_dtypes(include=["datetime"]).columns.tolist()
    text = df.select_dtypes(include=["object"]).columns.tolist()
    return {"numeric": numeric, "date": date, "text": text}

def detect_datetime_columns(df: pd.DataFrame) -> pd.DataFrame:
    for col in df.columns:
        try:
            df[col] = pd.to_datetime(df[col])
        except:
            continue
    return df

def column_selector(df: pd.DataFrame) -> Dict[str, str]:
    st.subheader("🧩 Select Columns for Analysis")
    types = get_column_types(df)
    selected = {}
    if types["date"]:
        selected["date_col"] = st.selectbox("📅 Date Column", types["date"])
    else:
        selected["date_col"] = None
    selected["value_col"] = st.selectbox("💰 Value Column (Numeric)", types["numeric"])
    selected["category_col"] = st.selectbox("🗂️ Category Column (Text)", types["text"])
    return selected

def store_in_session(key: str, df: pd.DataFrame):
    st.session_state[key] = df

def get_from_session(key: str) -> pd.DataFrame:
    return st.session_state.get(key, pd.DataFrame())

def preview_data(df: pd.DataFrame):
    st.subheader("👁️ Preview Data (Top 20 Rows)")
    st.dataframe(df.head(20), use_container_width=True)
    st.markdown(f"**Shape:** {df.shape[0]} rows × {df.shape[1]} columns")

def load_and_prepare_data() -> Tuple[pd.DataFrame, Dict[str, str]]:
    df = upload_data()
    if df.empty:
        return df, {}
    df = clean_column_names(df)
    df = detect_datetime_columns(df)
    df = fill_missing(df, strategy="mean")
    preview_data(df)
    selections = column_selector(df)
    store_in_session("cleaned_df", df)
    store_in_session("column_selections", selections)
    return df, selections

def describe_summary(df: pd.DataFrame):
    st.subheader("📊 Statistical Summary")
    st.dataframe(df.describe(include="all"), use_container_width=True)

def plot_preview(df: pd.DataFrame, col_x: str, col_y: str):
    st.subheader("📈 Quick Line Plot")
    if col_x and col_y:
        chart_df = df[[col_x, col_y]].dropna()
        st.line_chart(chart_df.set_index(col_x))